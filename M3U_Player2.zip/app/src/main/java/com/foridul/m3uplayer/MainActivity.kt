package com.foridul.m3uplayer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

data class Channel(val name: String, val url: String)

class MainActivity : AppCompatActivity() {
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var urlInput: EditText
    private lateinit var channelList: ListView
    private var player: ExoPlayer? = null
    private var cache: SimpleCache? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val channels = mutableListOf<Channel>()
    private var lastUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        playerView = findViewById(R.id.playerView)
        status = findViewById(R.id.status)
        urlInput = findViewById(R.id.urlInput)
        channelList = findViewById(R.id.channelList)

        findViewById<Button>(R.id.loadUrl).setOnClickListener {
            val value = urlInput.text.toString().trim()
            if (value.isNotEmpty()) loadPlaylist(value)
            else status.text = "একটি playlist URL দিন"
        }
        findViewById<Button>(R.id.openFile).setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(intent, PICK_FILE)
        }
        findViewById<Button>(R.id.retry).setOnClickListener {
            val current = player?.currentMediaItem
            if (current != null) {
                player?.prepare()
                player?.play()
            } else lastUrl?.let { play(it) }
        }
        channelList.setOnItemClickListener { _, _, position, _ ->
            channels.getOrNull(position)?.let { play(it.url) }
        }
        initializePlayer()
    }

    private fun initializePlayer() {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(30_000)
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent("M3UPlayer/1.0 (Android)")
        val database = StandaloneDatabaseProvider(this)
        cache = SimpleCache(
            cacheDir.resolve("media_cache"),
            LeastRecentlyUsedCacheEvictor(250L * 1024L * 1024L),
            database
        )
        val cacheFactory = CacheDataSource.Factory()
            .setCache(cache!!)
            .setUpstreamDataSourceFactory(httpFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                30_000,  // minimum buffer
                90_000,  // maximum buffer
                2_500,   // start playback
                5_000    // resume after rebuffer
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        player = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(cacheFactory))
            .build().also { exo ->
                playerView.player = exo
                exo.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        status.text = when (playbackState) {
                            Player.STATE_BUFFERING -> "দুর্বল নেটওয়ার্ক: বাফার হচ্ছে…"
                            Player.STATE_READY -> "চালু আছে"
                            Player.STATE_ENDED -> "ভিডিও শেষ"
                            else -> status.text
                        }
                    }
                    override fun onPlayerError(error: PlaybackException) {
                        status.text = "প্লে হচ্ছে না — RETRY চাপুন বা URL পরীক্ষা করুন"
                    }
                })
            }
    }

    private fun loadPlaylist(source: String) {
        lastUrl = source
        status.text = "Playlist লোড হচ্ছে…"
        worker.execute {
            try {
                val text = if (source.startsWith("http://") || source.startsWith("https://")) {
                    val connection = (URL(source).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 15_000
                        readTimeout = 30_000
                        instanceFollowRedirects = true
                    }
                    connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        .also { connection.disconnect() }
                } else {
                    contentResolver.openInputStream(Uri.parse(source))!!.bufferedReader(Charsets.UTF_8).use { it.readText() }
                }
                val parsed = parseM3u(text, source)
                runOnUiThread {
                    channels.clear()
                    channels.addAll(parsed)
                    channelList.adapter = ArrayAdapter(
                        this, R.layout.item_channel,
                        channels.map { it.name }
                    )
                    status.text = "${channels.size}টি চ্যানেল পাওয়া গেছে"
                    if (channels.isNotEmpty()) play(channels[0].url)
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Playlist লোড হয়নি: ${e.localizedMessage ?: "নেটওয়ার্ক সমস্যা"}" }
            }
        }
    }

    private fun parseM3u(content: String, playlistSource: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var pendingName: String? = null
        content.lineSequence().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    pendingName = line.substringAfterLast(",").trim().ifBlank { "Unknown channel" }
                }
                line.isNotEmpty() && !line.startsWith("#") -> {
                    val resolved = try {
                        URL(URL(playlistSource), line).toString()
                    } catch (_: Exception) { line }
                    result += Channel(pendingName ?: resolved.substringAfterLast("/"), resolved)
                    pendingName = null
                }
            }
        }
        return result
    }

    private fun play(url: String) {
        lastUrl = url
        val item = MediaItem.fromUri(url)
        player?.apply {
            setMediaItem(item)
            prepare()
            playWhenReady = true
        }
        status.text = "চ্যানেল চালু করার চেষ্টা চলছে…"
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) { }
                loadPlaylist(uri.toString())
            }
        }
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        playerView.player = null
        player?.release()
        player = null
        cache?.release()
        worker.shutdown()
        super.onDestroy()
    }

    companion object { private const val PICK_FILE = 1001 }
}
