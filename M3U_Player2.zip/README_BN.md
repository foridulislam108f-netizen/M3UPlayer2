# M3U Player — Android

## APK বানানোর নিয়ম (GitHub দিয়ে, কম্পিউটার/Android Studio ছাড়াই)

1. github.com এ লগইন করে **New repository** চাপুন। নাম দিন (যেমন `m3u-player`), **Create repository** চাপুন।
2. ZIP **Extract** করুন। ভেতরের **ফাইল ও ফোল্ডারগুলো** (`app`, `.github`, `build.gradle.kts`, `settings.gradle.kts` …) repository-র **একদম root-এ** আপলোড করুন। ZIP বা বাইরের ফোল্ডার নিজে আপলোড করবেন না।
   - **Add file → Upload files** → সব ফাইল/ফোল্ডার drag করুন → **Commit changes**।
   - `.github` ফোল্ডার লুকানো থাকতে পারে; কম্পিউটারে hidden files দেখান চালু করুন।
3. **Actions** ট্যাবে যান। build নিজে থেকেই শুরু হবে; না হলে **Build Android APK → Run workflow** চাপুন।
4. সবুজ ✔ হলে (৩–৭ মিনিট) run খুলে নিচে **Artifacts → M3U-Player-debug-APK** ডাউনলোড করুন।
5. ZIP extract করে `app-debug.apk` ফোনে ইনস্টল করুন (unknown source অনুমতি দিন)।

## ফিচার
- M3U playlist URL ও স্থানীয় M3U ফাইল
- M3U8 / HLS স্ট্রিম
- দুর্বল নেটওয়ার্কের জন্য বড় buffer, timeout, 250 MB cache
- চ্যানেল তালিকা, RETRY বাটন

## নোট
- এটি debug APK; Play Store-এর জন্য release signing লাগবে।
- কিছু IPTV সার্ভারে token/header লাগে; এই সংস্করণে সেটার UI নেই।
