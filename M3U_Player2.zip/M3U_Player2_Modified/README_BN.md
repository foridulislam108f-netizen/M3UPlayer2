# M3U Player — Android (v1.1)

## APK বানানোর নিয়ম (GitHub দিয়ে, কম্পিউটার/Android Studio ছাড়াই)

1. github.com এ লগইন করে **New repository** চাপুন। নাম দিন (যেমন `m3u-player`), **Create repository** চাপুন।
2. ZIP **Extract** করুন। ভেতরের **ফাইল ও ফোল্ডারগুলো** (`app`, `.github`, `build.gradle.kts`, `settings.gradle.kts` …) repository-র **একদম root-এ** আপলোড করুন। ZIP বা বাইরের ফোল্ডার নিজে আপলোড করবেন না।
   - **Add file → Upload files** → সব ফাইল/ফোল্ডার drag করুন → **Commit changes**।
   - `.github` ফোল্ডার লুকানো থাকতে পারে; কম্পিউটারে hidden files দেখান চালু করুন।
3. **Actions** ট্যাবে যান। build নিজে থেকেই শুরু হবে; না হলে **Build Android APK → Run workflow** চাপুন।
4. সবুজ ✔ হলে (৩–৭ মিনিট) run খুলে নিচে **Artifacts → M3U-Player-debug-APK** ডাউনলোড করুন।
5. ZIP extract করে `app-debug.apk` ফোনে ইনস্টল করুন (unknown source অনুমতি দিন)।

## নতুন ফিচার (v1.1)

- **M3U বিশেষ নির্দেশনা সঠিকভাবে পড়া**
  - `#EXTINF` অ্যাট্রিবিউট: `tvg-logo`, `group-title`, `tvg-name`, `user-agent` ইত্যাদি
  - `#EXTVLCOPT:http-user-agent=...`
  - `#EXTVLCOPT:http-referrer=...` / `http-referer`
  - `#EXTVLCOPT:http-header=Name: Value`
  - `#EXTGRP`
  - Relative URL ঠিকভাবে resolve

- **HLS + TS + DASH সাপোর্ট**
  - Media3 ExoPlayer + HLS + DASH মডিউল
  - Progressive TS স্ট্রিমও ভালোভাবে চলে

- **চ্যানেলভিত্তিক User-Agent ও Referrer**
  - প্রতিটি চ্যানেলের নিজস্ব UA / Referer / extra header ব্যবহার করে প্লে করে

- **সুন্দর Channel Logo ও Category**
  - লোগো দেখায় (Coil দিয়ে)
  - Category Spinner দিয়ে ফিল্টার করা যায়

- **দুর্বল নেটওয়ার্কের জন্য উন্নত Buffer + Adaptive Bitrate**
  - বড় buffer (min 50s, max 120s)
  - Back-buffer রাখে
  - Adaptive track selection (SD প্রাধান্য দিয়ে শুরু, পরে ABR)
  - 300 MB media cache
  - দীর্ঘ timeout

## নোট
- এটি debug APK; Play Store-এর জন্য release signing লাগবে।
- কিছু IPTV সার্ভারে টোকেন/কুকি লাগে — এখন `#EXTVLCOPT:http-header=` দিয়ে সাপোর্ট আছে।
