package com.foridul.m3uplayer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.AdaptiveTrackSelection
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import androidx.media3.ui.PlayerView
import coil.load
import coil.request.CachePolicy
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

data class Channel(
    val name: String,
    val url: String,
    val logo: String? = null,
    val group: String = "Uncategorized",
    val userAgent: String? = null,
    val referrer: String? = null,
    val headers: Map<String, String> = emptyMap()
)

class MainActivity : AppCompatActivity() {
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var urlInput: EditText
    private lateinit var channelList: ListView
    private lateinit var categorySpinner: Spinner
    private lateinit var bufferProgress: ProgressBar
    private lateinit var bufferLabel: TextView
    private lateinit var networkBadge: TextView

    private var player: ExoPlayer? = null
    private var cache: SimpleCache? = null
    private var trackSelector: DefaultTrackSelector? = null
    private val worker = Executors.newSingleThreadExecutor()

    private val allChannels = mutableListOf<Channel>()
    private val displayedChannels = mutableListOf<Channel>()
    private var currentChannel: Channel? = null
    private var lastPlaylistSource: String? = null

    // Weak-signal adaptive buffer config
    // Pre-buffers more aggressively so playback stays smooth on slow networks
    // High-ping / unstable network tuning (ping ~500ms, jitter ~42ms)
    private val BUFFER_MIN_MS         = 5_000    // start playing after just 5s
    private val BUFFER_MAX_MS         = 120_000  // keep 2 min ahead
    private val BUFFER_FOR_PLAYBACK_MS         = 1_500    // resume quickly after stall
    private val BUFFER_FOR_PLAYBACK_AFTER_REBUFFER_MS = 3_000
    private val CACHE_SIZE_BYTES      = 512L * 1024L * 1024L  // 512 MB on-disk cache
    private val CONNECT_TIMEOUT_MS    = 30_000   // generous for high-latency
    private val READ_TIMEOUT_MS       = 90_000   // allow slow first-byte on high ping

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        playerView      = findViewById(R.id.playerView)
        status          = findViewById(R.id.status)
        urlInput        = findViewById(R.id.urlInput)
        channelList     = findViewById(R.id.channelList)
        categorySpinner = findViewById(R.id.categorySpinner)
        bufferProgress  = findViewById(R.id.bufferProgress)
        bufferLabel     = findViewById(R.id.bufferLabel)
        networkBadge    = findViewById(R.id.networkBadge)

        findViewById<Button>(R.id.loadUrl).setOnClickListener {
            val value = urlInput.text.toString().trim()
            if (value.isNotEmpty()) loadPlaylist(value)
            else status.text = "একটি playlist URL দিন"
        }
        findViewById<Button>(R.id.openFile).setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            @Suppress("DEPRECATION")
            startActivityForResult(intent, PICK_FILE)
        }
        findViewById<Button>(R.id.retry).setOnClickListener {
            currentChannel?.let { play(it) } ?: lastPlaylistSource?.let { loadPlaylist(it) }
        }

        channelList.setOnItemClickListener { _, _, position, _ ->
            displayedChannels.getOrNull(position)?.let { play(it) }
        }

        categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                filterByCategory(position)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        initializePlayer()
    }

    private fun initializePlayer() {
        val database = StandaloneDatabaseProvider(this)
        // Large on-disk cache — previously buffered segments load instantly on retry
        cache = SimpleCache(
            cacheDir.resolve("media_cache"),
            LeastRecentlyUsedCacheEvictor(CACHE_SIZE_BYTES),
            database
        )

        // Adaptive bitrate: starts low, ramps up as bandwidth allows
        val bandwidthMeter = DefaultBandwidthMeter.Builder(this)
            .setResetOnNetworkTypeChange(false)   // keep estimate across cell handoffs
            .build()

        val trackSelectionFactory = AdaptiveTrackSelection.Factory()

        trackSelector = DefaultTrackSelector(this, trackSelectionFactory).apply {
            parameters = buildUponParameters()
                // prefer quality but not at the cost of stuttering
                .setForceHighestSupportedBitrate(false)
                .setAllowVideoMixedMimeTypeAdaptiveness(true)
                .setAllowAudioMixedMimeTypeAdaptiveness(true)
                // allow SD so the player can drop down on weak signal
                .setMaxVideoSizeSd()
                .build()
        }

        val renderersFactory = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true)   // fall back to SW decoder if HW fails

        // Generous buffer so a few seconds of packet loss don't stall playback
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                BUFFER_MIN_MS,
                BUFFER_MAX_MS,
                BUFFER_FOR_PLAYBACK_MS,
                BUFFER_FOR_PLAYBACK_AFTER_REBUFFER_MS
            )
            .setPrioritizeTimeOverSizeThresholds(true)    // start quickly, fill in background
            .setBackBuffer(30_000, true)                  // keep 30s back-buffer
            .setTargetBufferBytes(16 * 1024 * 1024)       // 16 MB RAM target
            .build()

        val httpFactory = buildHttpFactory()
        val cacheFactory = buildCacheFactory(httpFactory)

        player = ExoPlayer.Builder(this, renderersFactory)
            .setTrackSelector(trackSelector!!)
            .setLoadControl(loadControl)
            .setBandwidthMeter(bandwidthMeter)
            .setMediaSourceFactory(DefaultMediaSourceFactory(cacheFactory))
            .setHandleAudioBecomingNoisy(true)
            .build().also { exo ->
                playerView.player = exo
                exo.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(state: Int) {
                        when (state) {
                            Player.STATE_BUFFERING -> {
                                bufferProgress.visibility = View.VISIBLE
                                bufferLabel.visibility    = View.VISIBLE
                                status.text = "⏳ বাফার হচ্ছে… (দুর্বল নেটওয়ার্ক)"
                                networkBadge.text = "🔴 BUFFERING"
                            }
                            Player.STATE_READY -> {
                                bufferProgress.visibility = View.GONE
                                bufferLabel.visibility    = View.GONE
                                status.text = "▶ চালু • ${currentChannel?.name ?: ""}"
                                networkBadge.text = "🟢 LIVE"
                            }
                            Player.STATE_ENDED -> {
                                status.text = "✅ ভিডিও শেষ"
                                networkBadge.text = "⬛ ENDED"
                            }
                            else -> {}
                        }
                    }
                    override fun onPlayerError(error: PlaybackException) {
                        bufferProgress.visibility = View.GONE
                        bufferLabel.visibility    = View.GONE
                        networkBadge.text = "🔴 ERROR"
                        val msg = error.localizedMessage ?: error.errorCodeName
                        status.text = "❌ Error — RETRY চাপুন ($msg)"
                        // Auto-retry after 3 s on network errors
                        if (error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                            error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT) {
                            playerView.postDelayed({
                                currentChannel?.let { play(it) }
                            }, 3_000)
                        }
                    }
                })
            }
    }

    private fun buildHttpFactory(
        ua: String = "M3UPlayer/2.0 (Android; Media3)",
        extraHeaders: Map<String, String> = emptyMap()
    ) = DefaultHttpDataSource.Factory()
        .setConnectTimeoutMs(CONNECT_TIMEOUT_MS)
        .setReadTimeoutMs(READ_TIMEOUT_MS)
        .setAllowCrossProtocolRedirects(true)
        .setUserAgent(ua)
        .setDefaultRequestProperties(extraHeaders)

    private fun buildCacheFactory(http: DefaultHttpDataSource.Factory) =
        CacheDataSource.Factory()
            .setCache(cache!!)
            .setUpstreamDataSourceFactory(http)
            // Don't discard cache on error — keep segments for recovery
            .setFlags(0)

    private fun play(channel: Channel) {
        currentChannel = channel
        lastPlaylistSource = channel.url

        val props = mutableMapOf<String, String>()
        channel.userAgent?.takeIf { it.isNotBlank() }?.let { props["User-Agent"] = it }
        channel.referrer?.takeIf { it.isNotBlank() }?.let {
            props["Referer"] = it
            props["Referrer"] = it
        }
        props.putAll(channel.headers)

        val httpFactory = buildHttpFactory(
            ua = channel.userAgent ?: "M3UPlayer/2.0 (Android; Media3)",
            extraHeaders = props
        )
        val cacheFactory     = buildCacheFactory(httpFactory)
        val mediaSourceFactory = DefaultMediaSourceFactory(cacheFactory)

        val item = MediaItem.Builder()
            .setUri(channel.url)
            .setMediaId(channel.url)
            .setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder()
                    .setTitle(channel.name)
                    .setArtworkUri(channel.logo?.let { Uri.parse(it) })
                    .build()
            )
            .build()

        player?.apply {
            setMediaSource(mediaSourceFactory.createMediaSource(item))
            prepare()
            playWhenReady = true
        }
        status.text = "⏳ চালু করা হচ্ছে… ${channel.name}"
        networkBadge.text = "🟡 LOADING"
        bufferProgress.visibility = View.VISIBLE
        bufferLabel.visibility    = View.VISIBLE
    }

    private fun loadPlaylist(source: String) {
        lastPlaylistSource = source
        status.text = "📥 Playlist লোড হচ্ছে…"
        worker.execute {
            try {
                val text = if (source.startsWith("http://") || source.startsWith("https://")) {
                    val connection = (URL(source).openConnection() as HttpURLConnection).apply {
                        connectTimeout = CONNECT_TIMEOUT_MS
                        readTimeout    = READ_TIMEOUT_MS
                        instanceFollowRedirects = true
                        setRequestProperty("User-Agent", "M3UPlayer/2.0 (Android)")
                    }
                    connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        .also { connection.disconnect() }
                } else {
                    contentResolver.openInputStream(Uri.parse(source))!!
                        .bufferedReader(Charsets.UTF_8).use { it.readText() }
                }
                val parsed = parseM3u(text, source)
                runOnUiThread {
                    allChannels.clear()
                    allChannels.addAll(parsed)
                    setupCategories()
                    filterByCategory(0)
                    status.text = "✅ ${allChannels.size}টি চ্যানেল পাওয়া গেছে"
                    if (allChannels.isNotEmpty()) play(allChannels[0])
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "❌ Playlist লোড হয়নি: ${e.localizedMessage ?: "নেটওয়ার্ক সমস্যা"}"
                }
            }
        }
    }

    private fun parseM3u(content: String, playlistSource: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var pendingName: String? = null
        var pendingLogo: String? = null
        var pendingGroup: String = "Uncategorized"
        var pendingUa: String? = null
        var pendingRef: String? = null
        val pendingHeaders = mutableMapOf<String, String>()

        fun flush() {
            pendingName = null; pendingLogo = null
            pendingGroup = "Uncategorized"; pendingUa = null
            pendingRef = null; pendingHeaders.clear()
        }

        content.lineSequence().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val afterColon = line.substringAfter(":", "")
                    val commaIdx  = afterColon.lastIndexOf(',')
                    if (commaIdx >= 0) {
                        val attrsPart = afterColon.substring(0, commaIdx)
                        pendingName   = afterColon.substring(commaIdx + 1).trim().ifBlank { "Unknown" }
                        val attrRegex = Regex("""([\w-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s,]+))""")
                        attrRegex.findAll(attrsPart).forEach { m ->
                            val key   = m.groupValues[1].lowercase()
                            val value = m.groupValues[2].ifEmpty { m.groupValues[3].ifEmpty { m.groupValues[4] } }
                            when (key) {
                                "tvg-logo", "logo" -> pendingLogo = value
                                "group-title", "group" -> pendingGroup = value.ifBlank { "Uncategorized" }
                                "tvg-name" -> if (pendingName.isNullOrBlank() || pendingName == "Unknown") pendingName = value
                                "user-agent", "http-user-agent" -> pendingUa = value
                                "referrer", "http-referrer", "referer" -> pendingRef = value
                            }
                        }
                    } else {
                        pendingName = afterColon.trim().ifBlank { "Unknown" }
                    }
                }
                line.startsWith("#EXTVLCOPT", ignoreCase = true) -> {
                    val opt = line.substringAfter(":", "").trim()
                    when {
                        opt.startsWith("http-user-agent=", ignoreCase = true) -> pendingUa = opt.substringAfter("=")
                        opt.startsWith("http-referrer=", ignoreCase = true) ||
                        opt.startsWith("http-referer=", ignoreCase = true) -> pendingRef = opt.substringAfter("=")
                        opt.startsWith("http-header=", ignoreCase = true) -> {
                            val hv    = opt.substringAfter("=").trim()
                            val colon = hv.indexOf(':')
                            if (colon > 0) pendingHeaders[hv.substring(0, colon).trim()] = hv.substring(colon + 1).trim()
                        }
                        opt.startsWith("user-agent=", ignoreCase = true) -> pendingUa = opt.substringAfter("=")
                    }
                }
                line.startsWith("#EXTGRP", ignoreCase = true) ->
                    pendingGroup = line.substringAfter(":").trim().ifBlank { "Uncategorized" }
                line.isNotEmpty() && !line.startsWith("#") -> {
                    val resolved = try { URL(URL(playlistSource), line).toString() } catch (_: Exception) { line }
                    result += Channel(
                        name      = pendingName ?: resolved.substringAfterLast("/").substringBefore("?"),
                        url       = resolved,
                        logo      = pendingLogo,
                        group     = pendingGroup,
                        userAgent = pendingUa,
                        referrer  = pendingRef,
                        headers   = pendingHeaders.toMap()
                    )
                    flush()
                }
            }
        }
        return result
    }

    private fun setupCategories() {
        val groups = linkedSetOf("All")
        allChannels.forEach { groups.add(it.group) }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, groups.toList())
        categorySpinner.adapter = adapter
    }

    private fun filterByCategory(position: Int) {
        val selected = categorySpinner.selectedItem as? String ?: "All"
        displayedChannels.clear()
        if (selected == "All") displayedChannels.addAll(allChannels)
        else displayedChannels.addAll(allChannels.filter { it.group == selected })
        channelList.adapter = ChannelAdapter(this, displayedChannels)
    }

    private class ChannelAdapter(
        private val ctx: Context,
        private val items: List<Channel>
    ) : BaseAdapter() {
        override fun getCount()                              = items.size
        override fun getItem(position: Int)                  = items[position]
        override fun getItemId(position: Int)                = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(ctx)
                .inflate(R.layout.item_channel, parent, false)
            val ch = items[position]
            view.findViewById<TextView>(R.id.channelName).text  = ch.name
            view.findViewById<TextView>(R.id.channelGroup).text = ch.group
            val logoView = view.findViewById<ImageView>(R.id.channelLogo)
            if (!ch.logo.isNullOrBlank()) {
                logoView.load(ch.logo) {
                    crossfade(true)
                    memoryCachePolicy(CachePolicy.ENABLED)
                    diskCachePolicy(CachePolicy.ENABLED)
                    error(android.R.drawable.ic_menu_gallery)
                    placeholder(android.R.drawable.ic_menu_gallery)
                }
            } else {
                logoView.setImageResource(android.R.drawable.ic_menu_gallery)
            }
            return view
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                catch (_: Exception) {}
                loadPlaylist(uri.toString())
            }
        }
    }

    override fun onStop()    { super.onStop(); player?.pause() }
    override fun onDestroy() {
        playerView.player = null
        player?.release(); player = null
        cache?.release()
        worker.shutdown()
        super.onDestroy()
    }

    companion object { private const val PICK_FILE = 1001 }
}
