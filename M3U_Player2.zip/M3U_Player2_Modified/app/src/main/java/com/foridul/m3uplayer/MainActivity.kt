package com.foridul.m3uplayer

import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.AdaptiveTrackSelection
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import androidx.media3.ui.PlayerView
import coil.load
import coil.request.CachePolicy
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

// ─────────────────────────────────────────────
// Data model
// ─────────────────────────────────────────────
data class Channel(
    val name: String,
    val url: String,
    val logo: String? = null,
    val group: String = "Uncategorized",
    val userAgent: String? = null,
    val referrer: String? = null,
    val headers: Map<String, String> = emptyMap()
)

// ─────────────────────────────────────────────
// MainActivity
// ─────────────────────────────────────────────
class MainActivity : AppCompatActivity() {

    // Views
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var urlInput: EditText
    private lateinit var searchInput: EditText
    private lateinit var channelList: ListView
    private lateinit var categorySpinner: Spinner
    private lateinit var bufferProgress: ProgressBar
    private lateinit var bufferLabel: TextView
    private lateinit var networkBadge: TextView
    private lateinit var favBtn: ImageButton
    private lateinit var pipBtn: ImageButton
    private lateinit var sleepBtn: ImageButton
    private lateinit var fullscreenBtn: ImageButton

    // Player
    private var player: ExoPlayer? = null
    private var cache: SimpleCache? = null
    private var trackSelector: DefaultTrackSelector? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    // State
    private val allChannels = mutableListOf<Channel>()
    private val displayedChannels = mutableListOf<Channel>()
    private var currentChannel: Channel? = null
    private var lastPlaylistSource: String? = null
    private var retryCount = 0
    private val MAX_RETRIES = 5
    private var sleepTimer: Runnable? = null
    private var isFullscreen = false

    // Persistence
    private lateinit var prefs: SharedPreferences
    private val favChannels = mutableSetOf<String>()

    // ── Buffer / network settings ──────────────────
    private val BUFFER_MIN_MS                        = 5_000
    private val BUFFER_MAX_MS                        = 120_000
    private val BUFFER_FOR_PLAYBACK_MS               = 1_500
    private val BUFFER_FOR_PLAYBACK_AFTER_REBUFFER_MS = 3_000
    private val CACHE_SIZE_BYTES                     = 512L * 1024 * 1024
    private val CONNECT_TIMEOUT_MS                   = 30_000
    private val READ_TIMEOUT_MS                      = 90_000

    // ─────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep screen on while app is running
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("m3u_prefs", Context.MODE_PRIVATE)
        favChannels.addAll(prefs.getStringSet("favourites", emptySet()) ?: emptySet())

        bindViews()
        setupListeners()
        initializePlayer()

        // Restore last playlist
        prefs.getString("last_playlist", null)?.let {
            urlInput.setText(it)
            loadPlaylist(it)
        }
    }

    private fun bindViews() {
        playerView     = findViewById(R.id.playerView)
        status         = findViewById(R.id.status)
        urlInput       = findViewById(R.id.urlInput)
        searchInput    = findViewById(R.id.searchInput)
        channelList    = findViewById(R.id.channelList)
        categorySpinner= findViewById(R.id.categorySpinner)
        bufferProgress = findViewById(R.id.bufferProgress)
        bufferLabel    = findViewById(R.id.bufferLabel)
        networkBadge   = findViewById(R.id.networkBadge)
        favBtn         = findViewById(R.id.favBtn)
        pipBtn         = findViewById(R.id.pipBtn)
        sleepBtn       = findViewById(R.id.sleepBtn)
        fullscreenBtn  = findViewById(R.id.fullscreenBtn)
    }

    private fun setupListeners() {
        findViewById<Button>(R.id.loadUrl).setOnClickListener {
            val v = urlInput.text.toString().trim()
            if (v.isNotEmpty()) { prefs.edit().putString("last_playlist", v).apply(); loadPlaylist(v) }
            else status.text = "একটি playlist URL দিন"
        }
        findViewById<Button>(R.id.openFile).setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, PICK_FILE)
        }
        findViewById<Button>(R.id.retry).setOnClickListener {
            retryCount = 0
            currentChannel?.let { play(it) } ?: lastPlaylistSource?.let { loadPlaylist(it) }
        }
        // Show only favourites
        findViewById<Button>(R.id.favFilterBtn).setOnClickListener {
            displayedChannels.clear()
            displayedChannels.addAll(allChannels.filter { favChannels.contains(it.url) })
            channelList.adapter = ChannelAdapter(this, displayedChannels, favChannels, currentChannel)
            status.text = "⭐ ${displayedChannels.size}টি ফেভারিট"
        }
        channelList.setOnItemClickListener { _, _, pos, _ ->
            displayedChannels.getOrNull(pos)?.let { retryCount = 0; play(it) }
        }
        channelList.setOnItemLongClickListener { _, _, pos, _ ->
            displayedChannels.getOrNull(pos)?.let { ch ->
                if (favChannels.contains(ch.url)) favChannels.remove(ch.url)
                else favChannels.add(ch.url)
                prefs.edit().putStringSet("favourites", favChannels).apply()
                channelList.adapter = ChannelAdapter(this, displayedChannels, favChannels, currentChannel)
                toast(if (favChannels.contains(ch.url)) "⭐ Favourite added" else "Favourite removed")
            }
            true
        }
        categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = filterByCategory(pos)
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        // Live search
        searchInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { filterBySearch(s.toString()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        // Favourite toggle for current channel
        favBtn.setOnClickListener {
            currentChannel?.let { ch ->
                if (favChannels.contains(ch.url)) favChannels.remove(ch.url) else favChannels.add(ch.url)
                prefs.edit().putStringSet("favourites", favChannels).apply()
                updateFavIcon()
                toast(if (favChannels.contains(ch.url)) "⭐ Favourite added" else "Removed from favourites")
            }
        }
        // PiP
        pipBtn.setOnClickListener { enterPip() }
        // Sleep timer
        sleepBtn.setOnClickListener { showSleepTimerDialog() }
        // Fullscreen
        fullscreenBtn.setOnClickListener { toggleFullscreen() }
    }

    // ─────────────────────────────────────────────
    // Player initialisation — full codec + buffer config
    // ─────────────────────────────────────────────
    private fun initializePlayer() {
        val db = StandaloneDatabaseProvider(this)
        cache = SimpleCache(cacheDir.resolve("media_cache"),
            LeastRecentlyUsedCacheEvictor(CACHE_SIZE_BYTES), db)

        val bandwidthMeter = DefaultBandwidthMeter.Builder(this)
            .setResetOnNetworkTypeChange(false).build()

        // SW + HW decoders always available; fallback enabled
        val renderersFactory = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)   // HW → SW auto-fallback

        trackSelector = DefaultTrackSelector(this, AdaptiveTrackSelection.Factory()).apply {
            parameters = buildUponParameters()
                .setForceHighestSupportedBitrate(false)
                .setAllowVideoMixedMimeTypeAdaptiveness(true)
                .setAllowAudioMixedMimeTypeAdaptiveness(true)
                .setAllowVideoNonSeamlessAdaptiveness(true)
                .setAllowVideoMixedDecoderSupportAdaptiveness(true)
                .setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)   // no resolution cap
                .build()
        }

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                BUFFER_MIN_MS, BUFFER_MAX_MS,
                BUFFER_FOR_PLAYBACK_MS, BUFFER_FOR_PLAYBACK_AFTER_REBUFFER_MS)
            .setPrioritizeTimeOverSizeThresholds(true)
            .setBackBuffer(30_000, true)
            .setTargetBufferBytes(16 * 1024 * 1024)
            .build()

        player = ExoPlayer.Builder(this, renderersFactory)
            .setTrackSelector(trackSelector!!)
            .setLoadControl(loadControl)
            .setBandwidthMeter(bandwidthMeter)
            .setMediaSourceFactory(DefaultMediaSourceFactory(buildCacheFactory(buildHttpFactory())))
            .setHandleAudioBecomingNoisy(true)
            .build().also { exo ->
                playerView.player = exo
                exo.addListener(playerListener)
            }
    }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            when (state) {
                Player.STATE_BUFFERING -> {
                    bufferProgress.visibility = View.VISIBLE
                    bufferLabel.visibility = View.VISIBLE
                    networkBadge.text = "🟡 BUFFERING"
                    status.text = "⏳ বাফার হচ্ছে…"
                }
                Player.STATE_READY -> {
                    bufferProgress.visibility = View.GONE
                    bufferLabel.visibility = View.GONE
                    networkBadge.text = "🟢 LIVE"
                    retryCount = 0
                    status.text = "▶ ${currentChannel?.name ?: ""}"
                    updateFavIcon()
                    // Save last watched
                    currentChannel?.let { prefs.edit().putString("last_channel_url", it.url).apply() }
                }
                Player.STATE_ENDED -> { networkBadge.text = "⬛ ENDED"; status.text = "✅ শেষ" }
                else -> {}
            }
        }
        override fun onPlayerError(error: PlaybackException) {
            bufferProgress.visibility = View.GONE
            bufferLabel.visibility = View.GONE
            networkBadge.text = "🔴 ERROR"
            val msg = error.localizedMessage ?: error.errorCodeName
            status.text = "❌ Error ($msg)"
            // Smart auto-retry with exponential back-off
            if (retryCount < MAX_RETRIES) {
                val delayMs = (1_500L * (retryCount + 1)).coerceAtMost(15_000L)
                retryCount++
                status.text = "🔄 Auto-retry $retryCount/$MAX_RETRIES in ${delayMs/1000}s…"
                handler.postDelayed({ currentChannel?.let { play(it) } }, delayMs)
            } else {
                status.text = "❌ $MAX_RETRIES বার চেষ্টা হয়েছে — RETRY চাপুন"
            }
        }
    }

    // ─────────────────────────────────────────────
    // Playback
    // ─────────────────────────────────────────────
    private fun play(channel: Channel) {
        currentChannel = channel
        val props = mutableMapOf<String, String>()
        channel.userAgent?.takeIf { it.isNotBlank() }?.let { props["User-Agent"] = it }
        channel.referrer?.takeIf { it.isNotBlank() }?.let { props["Referer"] = it; props["Referrer"] = it }
        props.putAll(channel.headers)

        val factory = DefaultMediaSourceFactory(
            buildCacheFactory(buildHttpFactory(channel.userAgent ?: "M3UPlayer/3.0 (Android)", props)))

        val item = MediaItem.Builder()
            .setUri(channel.url).setMediaId(channel.url)
            .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder()
                .setTitle(channel.name)
                .setArtworkUri(channel.logo?.let { Uri.parse(it) })
                .build())
            .build()

        player?.run { setMediaSource(factory.createMediaSource(item)); prepare(); playWhenReady = true }
        status.text = "⏳ চালু করা হচ্ছে… ${channel.name}"
        networkBadge.text = "🟡 LOADING"
        bufferProgress.visibility = View.VISIBLE
        bufferLabel.visibility = View.VISIBLE
        updateFavIcon()
        // Highlight in list
        channelList.adapter = ChannelAdapter(this, displayedChannels, favChannels, currentChannel)
    }

    // ─────────────────────────────────────────────
    // HTTP / Cache factories
    // ─────────────────────────────────────────────
    private fun buildHttpFactory(
        ua: String = "M3UPlayer/3.0 (Android)",
        extra: Map<String, String> = emptyMap()
    ) = DefaultHttpDataSource.Factory()
        .setConnectTimeoutMs(CONNECT_TIMEOUT_MS)
        .setReadTimeoutMs(READ_TIMEOUT_MS)
        .setAllowCrossProtocolRedirects(true)
        .setUserAgent(ua)
        .setDefaultRequestProperties(extra)

    private fun buildCacheFactory(http: DefaultHttpDataSource.Factory) =
        CacheDataSource.Factory()
            .setCache(cache!!)
            .setUpstreamDataSourceFactory(http)
            .setFlags(0)   // keep cache even on error

    // ─────────────────────────────────────────────
    // Playlist loading & parsing
    // ─────────────────────────────────────────────
    private fun loadPlaylist(source: String) {
        lastPlaylistSource = source
        status.text = "📥 Playlist লোড হচ্ছে…"
        worker.execute {
            try {
                val text = if (source.startsWith("http://") || source.startsWith("https://")) {
                    (URL(source).openConnection() as HttpURLConnection).run {
                        connectTimeout = CONNECT_TIMEOUT_MS; readTimeout = READ_TIMEOUT_MS
                        instanceFollowRedirects = true
                        setRequestProperty("User-Agent", "M3UPlayer/3.0 (Android)")
                        inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                            .also { disconnect() }
                    }
                } else {
                    contentResolver.openInputStream(Uri.parse(source))!!
                        .bufferedReader(Charsets.UTF_8).use { it.readText() }
                }
                val parsed = parseM3u(text, source)
                runOnUiThread {
                    allChannels.clear(); allChannels.addAll(parsed)
                    setupCategories(); filterByCategory(0)
                    status.text = "✅ ${allChannels.size}টি চ্যানেল পাওয়া গেছে"
                    // Resume last watched channel
                    val lastUrl = prefs.getString("last_channel_url", null)
                    val resume = allChannels.firstOrNull { it.url == lastUrl } ?: allChannels.firstOrNull()
                    resume?.let { play(it) }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "❌ Playlist লোড হয়নি: ${e.localizedMessage ?: "নেটওয়ার্ক সমস্যা"}" }
            }
        }
    }

    private fun parseM3u(content: String, src: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var name: String? = null; var logo: String? = null
        var group = "Uncategorized"; var ua: String? = null; var ref: String? = null
        val hdrs = mutableMapOf<String, String>()
        fun flush() { name=null; logo=null; group="Uncategorized"; ua=null; ref=null; hdrs.clear() }
        content.lineSequence().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val ac = line.substringAfter(":", ""); val ci = ac.lastIndexOf(',')
                    if (ci >= 0) {
                        name = ac.substring(ci+1).trim().ifBlank { "Unknown" }
                        Regex("""([\w-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s,]+))""")
                            .findAll(ac.substring(0, ci)).forEach { m ->
                                val k = m.groupValues[1].lowercase()
                                val v = m.groupValues[2].ifEmpty { m.groupValues[3].ifEmpty { m.groupValues[4] } }
                                when(k) {
                                    "tvg-logo","logo" -> logo=v
                                    "group-title","group" -> group=v.ifBlank{"Uncategorized"}
                                    "tvg-name" -> if(name.isNullOrBlank()||name=="Unknown") name=v
                                    "user-agent","http-user-agent" -> ua=v
                                    "referrer","http-referrer","referer" -> ref=v
                                }
                            }
                    } else name = ac.trim().ifBlank { "Unknown" }
                }
                line.startsWith("#EXTVLCOPT", ignoreCase = true) -> {
                    val opt = line.substringAfter(":","").trim()
                    when {
                        opt.startsWith("http-user-agent=",ignoreCase=true) -> ua=opt.substringAfter("=")
                        opt.startsWith("http-referrer=",ignoreCase=true)||opt.startsWith("http-referer=",ignoreCase=true) -> ref=opt.substringAfter("=")
                        opt.startsWith("http-header=",ignoreCase=true) -> {
                            val hv=opt.substringAfter("=").trim(); val c=hv.indexOf(':')
                            if(c>0) hdrs[hv.substring(0,c).trim()]=hv.substring(c+1).trim()
                        }
                        opt.startsWith("user-agent=",ignoreCase=true) -> ua=opt.substringAfter("=")
                    }
                }
                line.startsWith("#EXTGRP",ignoreCase=true) -> group=line.substringAfter(":").trim().ifBlank{"Uncategorized"}
                line.isNotEmpty() && !line.startsWith("#") -> {
                    val url = try { URL(URL(src), line).toString() } catch(_:Exception){ line }
                    result += Channel(name ?: url.substringAfterLast("/").substringBefore("?"),
                        url, logo, group, ua, ref, hdrs.toMap())
                    flush()
                }
            }
        }
        return result
    }

    // ─────────────────────────────────────────────
    // Category & search filtering
    // ─────────────────────────────────────────────
    private fun setupCategories() {
        val groups = linkedSetOf("All"); allChannels.forEach { groups.add(it.group) }
        categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, groups.toList())
    }

    private fun filterByCategory(pos: Int) {
        val sel = categorySpinner.selectedItem as? String ?: "All"
        displayedChannels.clear()
        displayedChannels.addAll(if (sel == "All") allChannels else allChannels.filter { it.group == sel })
        val q = searchInput.text.toString()
        if (q.isNotBlank()) filterBySearch(q) else
            channelList.adapter = ChannelAdapter(this, displayedChannels, favChannels, currentChannel)
    }

    private fun filterBySearch(q: String) {
        val base = run {
            val sel = categorySpinner.selectedItem as? String ?: "All"
            if (sel == "All") allChannels else allChannels.filter { it.group == sel }
        }
        displayedChannels.clear()
        displayedChannels.addAll(if (q.isBlank()) base else base.filter { it.name.contains(q, ignoreCase = true) })
        channelList.adapter = ChannelAdapter(this, displayedChannels, favChannels, currentChannel)
    }

    // ─────────────────────────────────────────────
    // PiP
    // ─────────────────────────────────────────────
    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9)).build()
            enterPictureInPictureMode(params)
        } else toast("এই ডিভাইসে PiP সাপোর্ট নেই")
    }

    override fun onPictureInPictureModeChanged(inPip: Boolean, cfg: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(inPip, cfg)
        val uiVis = if (inPip) View.GONE else View.VISIBLE
        listOf<View>(
            findViewById(R.id.topBar), findViewById(R.id.inputRow),
            findViewById(R.id.buttonRow), status, bufferLabel,
            bufferProgress, findViewById(R.id.categoryRow),
            searchInput, channelList
        ).forEach { it.visibility = uiVis }
    }

    // ─────────────────────────────────────────────
    // Fullscreen
    // ─────────────────────────────────────────────
    private fun toggleFullscreen() {
        isFullscreen = !isFullscreen
        val pv = playerView
        if (isFullscreen) {
            pv.layoutParams = pv.layoutParams.also { it.height = ViewGroup.LayoutParams.MATCH_PARENT }
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            fullscreenBtn.setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
        } else {
            pv.layoutParams = pv.layoutParams.also { it.height = resources.getDimensionPixelSize(R.dimen.player_height) }
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            fullscreenBtn.setImageResource(android.R.drawable.ic_menu_zoom)
        }
    }

    // ─────────────────────────────────────────────
    // Sleep timer
    // ─────────────────────────────────────────────
    private fun showSleepTimerDialog() {
        val items = arrayOf("15 মিনিট", "30 মিনিট", "1 ঘণ্টা", "2 ঘণ্টা", "Cancel")
        AlertDialog.Builder(this)
            .setTitle("⏰ Sleep Timer")
            .setItems(items) { _, which ->
                sleepTimer?.let { handler.removeCallbacks(it) }
                val ms = when(which) { 0->15*60_000L; 1->30*60_000L; 2->60*60_000L; 3->120*60_000L; else->return@setItems }
                sleepTimer = Runnable { player?.pause(); toast("💤 Sleep timer — player বন্ধ হয়েছে") }
                handler.postDelayed(sleepTimer!!, ms)
                toast("⏰ ${items[which]} পরে বন্ধ হবে")
            }.show()
    }

    // ─────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────
    private fun updateFavIcon() {
        val isFav = currentChannel?.let { favChannels.contains(it.url) } ?: false
        favBtn.setImageResource(if (isFav) android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off)
    }
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ─────────────────────────────────────────────
    // Channel list adapter
    // ─────────────────────────────────────────────
    private class ChannelAdapter(
        private val ctx: Context,
        private val items: List<Channel>,
        private val favs: Set<String>,
        private val current: Channel?
    ) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(pos: Int, cv: View?, parent: ViewGroup): View {
            val view = cv ?: LayoutInflater.from(ctx).inflate(R.layout.item_channel, parent, false)
            val ch = items[pos]
            view.findViewById<TextView>(R.id.channelName).text = ch.name
            view.findViewById<TextView>(R.id.channelGroup).text = ch.group
            // Highlight currently playing
            view.setBackgroundColor(
                if (ch.url == current?.url) 0xFF1A2F5A.toInt() else android.graphics.Color.TRANSPARENT)
            // Star icon
            view.findViewById<ImageView>(R.id.favIcon).setImageResource(
                if (favs.contains(ch.url)) android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off)
            // Logo
            val logoView = view.findViewById<ImageView>(R.id.channelLogo)
            if (!ch.logo.isNullOrBlank()) {
                logoView.load(ch.logo) {
                    crossfade(true); memoryCachePolicy(CachePolicy.ENABLED)
                    diskCachePolicy(CachePolicy.ENABLED)
                    error(android.R.drawable.ic_menu_gallery)
                    placeholder(android.R.drawable.ic_menu_gallery)
                }
            } else logoView.setImageResource(android.R.drawable.ic_menu_gallery)
            return view
        }
    }

    // ─────────────────────────────────────────────
    // Lifecycle
    // ─────────────────────────────────────────────
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        @Suppress("DEPRECATION") super.onActivityResult(req, res, data)
        if (req == PICK_FILE && res == RESULT_OK) {
            data?.data?.let { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                catch (_: Exception) {}
                loadPlaylist(uri.toString())
            }
        }
    }
    override fun onStop()    { super.onStop(); player?.pause() }
    override fun onDestroy() {
        sleepTimer?.let { handler.removeCallbacks(it) }
        playerView.player = null
        player?.release(); player = null
        cache?.release(); worker.shutdown()
        super.onDestroy()
    }

    companion object { private const val PICK_FILE = 1001 }
}
